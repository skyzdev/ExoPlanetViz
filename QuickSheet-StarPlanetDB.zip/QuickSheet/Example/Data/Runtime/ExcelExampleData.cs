using UnityEngine;
using System.Collections;

///
/// !!! Machine generated code !!!
/// !!! DO NOT CHANGE Tabs to Spaces !!!
/// 
[System.Serializable]
public class ExcelExampleData
{
  [SerializeField]
  int id;
  public int Id { get {return id; } set { id = value;} }
  
  [SerializeField]
  string name;
  public string Name { get {return name; } set { name = value;} }
  
  [SerializeField]
  float strength;
  public float Strength { get {return strength; } set { strength = value;} }
  
  [SerializeField]
  Difficulty difficulty;
  public Difficulty DIFFICULTY { get {return difficulty; } set { difficulty = value;} }
  
}