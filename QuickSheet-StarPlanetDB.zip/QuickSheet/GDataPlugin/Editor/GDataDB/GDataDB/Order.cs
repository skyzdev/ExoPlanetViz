namespace GDataDB {
    /// <summary>
    /// Sort order
    /// </summary>
    public class Order {
        public bool Descending { get; set; }
        public string ColumnName { get; set; }
    }
}